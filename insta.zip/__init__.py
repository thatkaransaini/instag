from .api import API
from .bot import Bot

assert API  # silence pyflakes
assert Bot  # silence pyflakes
