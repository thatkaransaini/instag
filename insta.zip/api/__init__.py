from .api import API

assert API  # silence pyflakes
